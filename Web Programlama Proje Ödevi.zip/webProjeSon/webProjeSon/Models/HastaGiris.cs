﻿using webProjeOdev.Models;

namespace webProjeSon.Models
{
    public class HastaGiris
    {
        public string tcHasta { get; set; }
        public string parola { get; set; }
    }
}
